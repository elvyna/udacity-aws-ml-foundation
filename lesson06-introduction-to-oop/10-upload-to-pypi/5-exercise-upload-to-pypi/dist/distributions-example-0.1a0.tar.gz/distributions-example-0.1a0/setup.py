from setuptools import setup

setup(name='distributions-example',
      version='0.1a',
      description='Gaussian and binomial distribution class',
      packages=['distributions'],
      zip_safe=False)
